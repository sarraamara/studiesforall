package edu.episen.si.fise.progcommu.exam.ex4.server.service;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RmiService extends Remote {
    String getString() throws RemoteException;
}
