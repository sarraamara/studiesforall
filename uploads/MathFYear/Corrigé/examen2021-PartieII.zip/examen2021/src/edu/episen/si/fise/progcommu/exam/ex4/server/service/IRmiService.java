package edu.episen.si.fise.progcommu.exam.ex4.server.service;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class IRmiService extends UnicastRemoteObject implements RmiService {
    public IRmiService() throws RemoteException {
    }

    @Override
    public String getString() throws RemoteException {
        return "Appel Distant";
    }
}
