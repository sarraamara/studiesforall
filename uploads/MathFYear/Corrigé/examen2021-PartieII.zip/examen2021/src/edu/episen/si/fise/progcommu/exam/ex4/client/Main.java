package edu.episen.si.fise.progcommu.exam.ex4.client;

import edu.episen.si.fise.progcommu.exam.ex4.server.service.RmiService;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Logger;

public class Main {
    final static Logger logger = Logger.getLogger(Main.class.getName());
    public static void main(String[] args) throws Exception {
        logger.info("Service Rmi started");
        final int PORT = 60000;
        final String url = "rmi://localhost:" + PORT + "/rmi/string";
        Registry register =  LocateRegistry.getRegistry(PORT);

        RmiService service = (RmiService) register.lookup(url);

        String string = service.getString();

        logger.info(string);
    }
}
