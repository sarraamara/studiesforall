package edu.episen.si.fise.progcommu.exam;

public class Main {
}
