package edu.episen.si.fise.progcommu.exam.ex4.server;

import edu.episen.si.fise.progcommu.exam.ex4.server.service.IRmiService;
import edu.episen.si.fise.progcommu.exam.ex4.server.service.RmiService;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.logging.Logger;

public class App {
    final static Logger logger = Logger.getLogger(App.class.getName());
    public static void main(String[] args) throws RemoteException {

        logger.info("Service Rmi started");
        final int PORT = 60000;
        final String url = "rmi://localhost:" + PORT + "/rmi/string";

        Registry registry = LocateRegistry.createRegistry(PORT);

        RmiService service = new IRmiService();

        registry.rebind(url, service);

        logger.info("Service Rmi is able to serve clients");
    }
}
