package edu.episen.si.fise.progcommu.exam.ex1;

public class ThreadHandle {
    private  static Piece piece = new Piece();

    static class LionEntree extends Thread {
        @Override
        public void run() {
            final int k = 1000;
                for (int i = 0; i < k; i++) {
                    piece.lionVeutEntrer();
                }
        }
    }

    static class LionSortie extends Thread {
        @Override
        public void run() {
            final int k = 1000;
            for (int i = 0; i < k; i++) {
                piece.lionQuitteLaPièce();
            }
        }
    }

    static class AntilopeEntree extends Thread {
        @Override
        public void run() {
            final int k = 1000;
            for (int i = 0; i < k; i++) {
                piece.antilopeVeutEntrer();
            }
        }
    }

    static class AntilopeQuitte extends Thread {
        @Override
        public void run() {
            final int k = 1000;
            for (int i = 0; i < k; i++) {
                piece.antilopeQuitteLaPièce();
            }
        }
    }


    public static void main(String[] args) {
        for (int i = 0; i < 4; i++) {
            new LionEntree().start();
            new LionSortie().start();
            new AntilopeEntree().start();
            new AntilopeQuitte().start();
        }
    }
}
