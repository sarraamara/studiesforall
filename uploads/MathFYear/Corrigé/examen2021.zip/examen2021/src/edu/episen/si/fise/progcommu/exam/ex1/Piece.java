package edu.episen.si.fise.progcommu.exam.ex1;

import java.util.ArrayList;
import java.util.List;

public class Piece {
    private List<Animal> animaux = new ArrayList<>();
    private Etat etat = Etat.VIDE;


    private void changeEtat() {
        if(animaux.isEmpty()) {
            etat = Etat.VIDE;
        } else if(animaux.contains(Animal.LION)) {
            etat = Etat.OccupeParLion;
        } else if(animaux.contains(Animal.ANTILOPE)) {
            etat = Etat.OccupeParAntilope;
        }
    }


    public void lionQuitteLaPièce() {
        if(animaux.contains(Animal.LION)) {
            animaux.remove(Animal.LION);
            changeEtat();
            System.out.println("Lion a quitte , etat : " + etat);
        }
    }

    public void antilopeQuitteLaPièce() {
        if(animaux.contains(Animal.ANTILOPE)) {
            animaux.remove(Animal.ANTILOPE);
            changeEtat();
            System.out.println("antilope a quitte , etat : " + etat);
        }
    }

    public void lionVeutEntrer() {
        if(!animaux.contains(Animal.ANTILOPE) || animaux.isEmpty()) {
            animaux.add(Animal.LION);
            changeEtat();
            System.out.println("Lion a entree , etat : " + etat);

        }
    }

    public void antilopeVeutEntrer() {
        if(animaux.contains(Animal.ANTILOPE) || animaux.isEmpty()) {
            animaux.add(Animal.ANTILOPE);
            changeEtat();
            System.out.println("antilope a entree , etat : " + etat);
        }
    }

    public List<Animal> getAnimaux() {
        return animaux;
    }

    public Etat getEtat() {
        return etat;
    }
}
