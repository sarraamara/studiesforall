package edu.episen.si.fise.progcommu.exam.ex1;

public enum Etat {
    VIDE, OccupeParLion, OccupeParAntilope;
}
