package edu.episen.si.fise.progcommu.exam.ex1;

public enum Animal {
    LION, ANTILOPE;
}
