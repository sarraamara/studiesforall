import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import javax.swing.JFrame;


public class ControlGame implements ActionListener {
	int [][] t=DataGame.getTabJeu();
	JFrame WindowGame=DataGame.WindowGame;
	int abs,ord;
	public ControlGame(int abs,int ord)
	{
		this.abs=abs;
		this.ord=ord;
	}
	public static void initTabJeu()
	{
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				DataGame.setTabJeu(i, j, 0);
			}
		}
	}//Fin init
	
	boolean verifLigne()
	{
		
		for(int col=0;col<3;col++)
		{
			if(t[abs][col]!=t[abs][ord])
				return false;
		}
		return true;
	}
	boolean verifColonne()
	{
		
		for(int lig=0;lig<3;lig++)
		{
			if(t[lig][ord]!=t[abs][ord])
				return false;
		}
		return true;
	}
	boolean verifDiagonale()
	{
		if(abs!=ord) {return false;}
		else {
		for(int j=0;j<3;j++)
			{
				if(t[j][j]!=t[abs][ord])
					return false;
			}
		return true;
		
		}
	}
	boolean verifDiagonale2()
	{
		if((abs+ord+1)!=3) {return false;}
		else {
		for(int j=0;j<3;j++)
			{
				if(t[j][2-j]!=t[abs][ord])
					return false;
			}
		return true;
		
		}
	}
	boolean verif()
	{ return(verifLigne()||verifColonne()||verifDiagonale()||verifDiagonale2());}
	
	
	public void actionPerformed(ActionEvent e)
	{  
	   JButton b= (JButton)e.getSource();
		DataGame.setnbreEssai();
		int nb= DataGame.getnbreEssai();
		
		int numJoueur;
		
		if(nb%2==1) { DataGame.setTabJeu(abs, ord, 1); b.setText("X"); b.removeActionListener(this); numJoueur=DataGame.Player1;}
		else {
			DataGame.setTabJeu(abs, ord, 2); b.setText("O");b.removeActionListener(this); numJoueur=DataGame.Player2;
		}
		if(verif())
		{   
			GameView.showResult(true, numJoueur);
		}
		else if(nb==9)
		{
			GameView.showResult(false, numJoueur);
		}
	
   }
}
