import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GameView {

	public JFrame WindowGame=DataGame.WindowGame;
	
	private class PanneauCouleur extends JPanel{
		  int abs,ord; JButton bouton=new JButton();
		  public PanneauCouleur(int i,int j)
		  {   
			  abs=i;ord=j;	
			  this.setSize(DataGame.WIDTH_PANEL, DataGame.HEIGHT_PANEL);
			  bouton.setBackground(Color.decode("#646881"));
			  bouton.setFont(new Font("Arial",Font.BOLD,100));
			  this.setLayout(new BorderLayout());
			  this.setSize(DataGame.WIDTH_PANEL, DataGame.HEIGHT_PANEL);
			  this.setBorder(BorderFactory.createLineBorder(Color.white, 3));
			  bouton.addActionListener(new ControlGame(abs,ord));
			  this.add(bouton);
			  
			  
		  }
	}
	
	public GameView()
	{  WindowGame.setVisible(true);
	 
		WindowGame.setLocationRelativeTo(null);
		WindowGame.setLayout(new GridLayout(3,3));
		WindowGame.setBackground(Color.LIGHT_GRAY);
		WindowGame.setSize(DataGame.WIDTH, DataGame.HEIGHT);
		WindowGame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ControlGame.initTabJeu(); //init en 0 le tabjeu
		PanneauCouleur panel;
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<3;j++)
			{
				panel=new PanneauCouleur(i,j);
				WindowGame.getContentPane().add(panel);
				
				
			}
			
			
		}	
	}
	public static void showResult(boolean b,int numJoueur)
	{
		if(b)
			{System.out.println("F�licitations! Joueur "+numJoueur+" a gagn�."); System.exit(0);}
			else
				{System.out.println("GameOver! Personne n'a gagn�.");System.exit(0);}
	}
	public static void main(String[] args)
	{
		GameView game=new GameView();
		
		
	}
	
	

}
