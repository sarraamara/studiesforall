
import javax.swing.JFrame;


public class DataGame {
 private static int[][] tabJeu=new int[3][3];
 private static int nbreEssai=0;
 public final static int Player1=1;
 public final static int Player2=2;
 public final static int WIDTH=500;
 public final static int HEIGHT=500;
 public final static int HEIGHT_PANEL=100;
 public final static int WIDTH_PANEL=100;
 public static JFrame WindowGame=new JFrame("Tic Tac Toe");

  public static int[][] getTabJeu(){return(tabJeu);}
  
  public static int getnbreEssai(){return(nbreEssai);}
  
  public static void setnbreEssai() { nbreEssai++; }
  
  public static void setTabJeu(int i,int j,int x) { tabJeu[i][j]=x;}
  
  
	  
  }
  
 

